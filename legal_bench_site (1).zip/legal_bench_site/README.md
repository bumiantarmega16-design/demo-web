# Legal Bench Demo Website

This is a static, browser-ready demo. It does not require Node.js, npm, a database, or an API key.

## Open locally
1. Extract this folder.
2. Double-click `index.html`.
3. It opens in your default browser.

## Publish online with GitHub Pages
1. Create a new GitHub repository (for example `legal-bench-demo`).
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. The public URL will be shown in Settings → Pages.

## Demo limitations
- Uses illustrative sample data only.
- New cases are kept in browser memory for the current page session and are not shared with other users.
- No real login, backend, persistent database, or live AI model API is connected.
- Do not enter confidential client documents or personal data.
